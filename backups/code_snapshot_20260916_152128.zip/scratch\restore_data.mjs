import { createClient } from '@supabase/supabase-js'
import fs from 'fs'
import path from 'path'

// Load .env variables
const envContent = fs.readFileSync('c:/Users/davis/Documents/Agromercantil/.env', 'utf8');
const urlMatch = envContent.match(/VITE_SUPABASE_URL\s*=\s*(.+)/);
const keyMatch = envContent.match(/VITE_SUPABASE_ANON_KEY\s*=\s*(.+)/);

if (!urlMatch || !keyMatch) {
  console.error('Failed to parse .env file');
  process.exit(1);
}

const SUPABASE_URL = urlMatch[1].trim();
const SUPABASE_KEY = keyMatch[1].trim();

console.log('Connecting to new Supabase:', SUPABASE_URL);
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

const backupDir = 'c:/Users/davis/Documents/Agromercantil/scratch/backup';
const tablesInOrder = [
  'branches',
  'owners',
  'drivers',
  'vehicles',
  'products',
  'clients',
  'cargos',
  'shipments',
  'app_users',
  'tickets',
  'profile_permissions',
  'app_settings',
  'tool_clients',
  'tool_stays',
  'tool_quotes'
];

async function restore() {
  console.log('Starting data migration to the new database...');

  for (const table of tablesInOrder) {
    const filePath = path.join(backupDir, `${table}.json`);
    if (!fs.existsSync(filePath)) {
      console.log(`Backup file for ${table} does not exist. Skipping.`);
      continue;
    }

    const rows = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    if (rows.length === 0) {
      console.log(`Table ${table} is empty. Skipping.`);
      continue;
    }

    console.log(`Migrating ${rows.length} rows to ${table}...`);

    // Insert in batches of 100 to avoid request size limits
    const batchSize = 100;
    for (let i = 0; i < rows.length; i += batchSize) {
      const batch = rows.slice(i, i + batchSize);
      const { error } = await supabase.from(table).insert(batch);
      if (error) {
        console.error(`Error migrating batch ${i} to ${table}:`, error.message);
        console.log('Failing batch sample:', batch[0]);
        // Continue to let other tables/rows migrate if possible
      }
    }
    console.log(`Finished migrating table ${table}!`);
  }

  console.log('Database migration complete!');
}

restore();
