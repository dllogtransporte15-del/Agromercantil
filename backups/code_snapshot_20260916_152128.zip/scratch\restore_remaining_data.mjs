import { createClient } from '@supabase/supabase-js'
import fs from 'fs'
import path from 'path'

const envContent = fs.readFileSync('c:/Users/davis/Documents/Agromercantil/.env', 'utf8');
const urlMatch = envContent.match(/VITE_SUPABASE_URL\s*=\s*(.+)/);
const keyMatch = envContent.match(/VITE_SUPABASE_ANON_KEY\s*=\s*(.+)/);

if (!urlMatch || !keyMatch) {
  console.error('Failed to parse .env file');
  process.exit(1);
}

const SUPABASE_URL = urlMatch[1].trim();
const SUPABASE_KEY = keyMatch[1].trim();

console.log('Connecting to Supabase...');
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

const backupDir = 'c:/Users/davis/Documents/Agromercantil/scratch/backup';
const tablesToMigrate = ['tool_clients', 'tool_stays'];

async function restoreRemaining() {
  console.log('Migrating remaining tool tables...');

  for (const table of tablesToMigrate) {
    const filePath = path.join(backupDir, `${table}.json`);
    if (!fs.existsSync(filePath)) {
      console.log(`Backup file for ${table} does not exist. Skipping.`);
      continue;
    }

    const rows = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    if (rows.length === 0) {
      console.log(`Table ${table} is empty. Skipping.`);
      continue;
    }

    console.log(`Clearing table ${table} before insert...`);
    await supabase.from(table).delete().neq('id', '00000000-0000-0000-0000-000000000000');

    console.log(`Migrating ${rows.length} rows to ${table}...`);
    const { error } = await supabase.from(table).insert(rows);
    if (error) {
      console.error(`Error migrating table ${table}:`, error.message);
    } else {
      console.log(`Table ${table} successfully migrated!`);
    }
  }

  console.log('Remaining tool tables migration complete!');
}

restoreRemaining();
