import fs from 'fs';
import path from 'path';

const searchDir = 'c:/Users/davis/Documents/Agromercantil';
const ignoreDirs = ['node_modules', 'dist', '.git', '.vercel', 'migrated_prompt_history', 'scratch'];
const ignoreFiles = ['package-lock.json'];

function replaceInFile(filePath) {
  try {
    let content = fs.readFileSync(filePath, 'utf8');
    let original = content;

    // Perform case-preserved replacements
    content = content.replace(/rodochagas/g, 'agromarcantil');
    content = content.replace(/Rodochagas/g, 'Agromarcantil');
    content = content.replace(/RODOCHAGAS/g, 'AGROMARCANTIL');
    content = content.replace(/RodoChagas/g, 'Agromarcantil');
    content = content.replace(/rodochagas/gi, 'agromarcantil'); // fallback safety

    if (content !== original) {
      fs.writeFileSync(filePath, content, 'utf8');
      console.log(`Replaced in: ${filePath}`);
    }
  } catch (err) {
    console.error(`Error processing ${filePath}:`, err.message);
  }
}

function walkDir(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);

    if (stat.isDirectory()) {
      if (!ignoreDirs.includes(file)) {
        walkDir(fullPath);
      }
    } else {
      if (!ignoreFiles.includes(file)) {
        const ext = path.extname(file);
        if (['.json', '.html', '.css', '.ts', '.tsx', '.js', '.jsx', '.md', '.txt', '.toml'].includes(ext)) {
          replaceInFile(fullPath);
        }
      }
    }
  }
}

console.log('Starting brand replacement (rodochagas -> agromarcantil)...');
walkDir(searchDir);
console.log('Brand replacement complete!');
