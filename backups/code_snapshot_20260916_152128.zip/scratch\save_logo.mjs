import fs from 'fs';

const base64Data = fs.readFileSync('c:/Users/davis/Documents/Agromercantil/logo_base64.txt', 'utf8').trim();

// PNG files start with iVBORw0KGg
console.log('Base64 length:', base64Data.length);
console.log('Starts with:', base64Data.substring(0, 30));

const buffer = Buffer.from(base64Data, 'base64');
fs.writeFileSync('c:/Users/davis/Documents/Agromercantil/scratch/new_logo.png', buffer);
console.log('Saved to scratch/new_logo.png');
