import { createClient } from '@supabase/supabase-js'
import fs from 'fs'
import path from 'path'

const supabase = createClient(
  'https://gyvnhvnuidrfmqzielmv.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd5dm5odm51aWRyZm1xemllbG12Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQwMTY5ODksImV4cCI6MjA4OTU5Mjk4OX0.dK_l3INxOB9_HVYte43PCXFQLe8DnXgPitcxhNK4x30'
)

const tables = [
  'app_users', 'clients', 'owners', 'drivers', 'vehicles', 'products', 
  'cargos', 'shipments', 'branches', 'profile_permissions', 'app_settings', 'tickets',
  'tool_clients', 'tool_stays', 'tool_quotes'
];

async function backupData() {
  console.log('Starting backup of old database...');
  const backupDir = 'c:/Users/davis/Documents/Agromercantil/scratch/backup';
  if (!fs.existsSync(backupDir)) {
    fs.mkdirSync(backupDir, { recursive: true });
  }

  for (const table of tables) {
    console.log(`Backing up table ${table}...`);
    // PostgREST limits single fetch to 1000 items, let's fetch in pages if needed
    let allData = [];
    let from = 0;
    let to = 999;
    let finished = false;

    while (!finished) {
      const { data, error } = await supabase
        .from(table)
        .select('*')
        .range(from, to);

      if (error) {
        console.error(`Error on table ${table}:`, error.message);
        break;
      }

      allData = allData.concat(data);
      if (data.length < 1000) {
        finished = true;
      } else {
        from += 1000;
        to += 1000;
      }
    }

    const filePath = path.join(backupDir, `${table}.json`);
    fs.writeFileSync(filePath, JSON.stringify(allData, null, 2), 'utf8');
    console.log(`Table ${table} successfully backed up! Saved ${allData.length} rows to ${filePath}`);
  }

  console.log('Database backup complete!');
}

backupData();
