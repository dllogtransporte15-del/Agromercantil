import fs from 'fs';

const logoPngPath = 'c:/Users/davis/Documents/Agromercantil/scratch/settings_logo.png';
const logoTxtPath = 'c:/Users/davis/Documents/Agromercantil/logo_base64.txt';

console.log('Reading settings_logo.png and converting to base64...');
const logoBuffer = fs.readFileSync(logoPngPath);
const base64Logo = logoBuffer.toString('base64');

fs.writeFileSync(logoTxtPath, base64Logo, 'utf8');
console.log('Successfully updated logo_base64.txt with the new Agromercantil logo!');
