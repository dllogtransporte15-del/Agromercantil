import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  'https://gyvnhvnuidrfmqzielmv.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd5dm5odm51aWRyZm1xemllbG12Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQwMTY5ODksImV4cCI6MjA4OTU5Mjk4OX0.dK_l3INxOB9_HVYte43PCXFQLe8DnXgPitcxhNK4x30'
)

async function dumpUsers() {
  console.log('Querying app_users from old database...');
  const { data: users, error } = await supabase
    .from('app_users')
    .select('*');

  if (error) {
    console.error('Error fetching users:', error.message);
  } else {
    console.log('Users found:', JSON.stringify(users, null, 2));
  }
}

dumpUsers();
