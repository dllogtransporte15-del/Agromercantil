import { createClient } from '@supabase/supabase-js'
import fs from 'fs'

const envContent = fs.readFileSync('c:/Users/davis/Documents/Agromercantil/.env', 'utf8');
const urlMatch = envContent.match(/VITE_SUPABASE_URL\s*=\s*(.+)/);
const keyMatch = envContent.match(/VITE_SUPABASE_ANON_KEY\s*=\s*(.+)/);

if (!urlMatch || !keyMatch) {
  console.error('Failed to parse .env file');
  process.exit(1);
}

const SUPABASE_URL = urlMatch[1].trim();
const SUPABASE_KEY = keyMatch[1].trim();

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

async function saveLogo() {
  console.log('Fetching app_settings...');
  const { data, error } = await supabase.from('app_settings').select('company_logo').eq('id', 1).single();
  if (error || !data || !data.company_logo) {
    console.error('Error or no logo found in settings:', error);
    return;
  }

  const base64Str = data.company_logo.split(',')[1] || data.company_logo;
  console.log('Base64 length:', base64Str.length);
  const buffer = Buffer.from(base64Str, 'base64');
  fs.writeFileSync('c:/Users/davis/Documents/Agromercantil/scratch/settings_logo.png', buffer);
  console.log('Saved settings logo to scratch/settings_logo.png');
}

saveLogo();
