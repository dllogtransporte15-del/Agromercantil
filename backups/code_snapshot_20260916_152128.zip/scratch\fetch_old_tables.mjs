import fetch from 'node-fetch'

const url = 'https://gyvnhvnuidrfmqzielmv.supabase.co/rest/v1/?apikey=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd5dm5odm51aWRyZm1xemllbG12Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQwMTY5ODksImV4cCI6MjA4OTU5Mjk4OX0.dK_l3INxOB9_HVYte43PCXFQLe8DnXgPitcxhNK4x30';

async function getOpenApi() {
  const response = await fetch(url);
  const data = await response.json();
  console.log('Definitions found:', Object.keys(data.definitions || {}));
  console.log('Full JSON saved to scratch/old_openapi.json');
  
  // Save full openapi json for reference
  import('fs').then(fs => {
    fs.writeFileSync('c:/Users/davis/Documents/Agromercantil/scratch/old_openapi.json', JSON.stringify(data, null, 2));
  });
}

getOpenApi();
