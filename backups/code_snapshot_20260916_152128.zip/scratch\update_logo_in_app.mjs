import fs from 'fs';

const appPath = 'c:/Users/davis/Documents/Agromercantil/App.tsx';
const logoPngPath = 'c:/Users/davis/Documents/Agromercantil/scratch/settings_logo.png';

console.log('Reading App.tsx...');
let appContent = fs.readFileSync(appPath, 'utf8');

console.log('Reading settings_logo.png and converting to base64...');
const logoBuffer = fs.readFileSync(logoPngPath);
const base64Logo = `data:image/png;base64,${logoBuffer.toString('base64')}`;

console.log('Replacing RODOCHAGAS_LOGO_BASE64 with new base64 logo in App.tsx...');
// We look for: const RODOCHAGAS_LOGO_BASE64 = "data:image/png;base64,...";
const regex = /const RODOCHAGAS_LOGO_BASE64 = "[^"]+";/;

if (regex.test(appContent)) {
  appContent = appContent.replace(regex, `const RODOCHAGAS_LOGO_BASE64 = "${base64Logo}";`);
  fs.writeFileSync(appPath, appContent, 'utf8');
  console.log('Successfully updated logo in App.tsx!');
} else {
  // Try case-replaced name since we ran rename_brand.mjs earlier
  const regexRenamed = /const AGROMARCANTIL_LOGO_BASE64 = "[^"]+";/;
  if (regexRenamed.test(appContent)) {
    appContent = appContent.replace(regexRenamed, `const RODOCHAGAS_LOGO_BASE64 = "${base64Logo}";`);
    fs.writeFileSync(appPath, appContent, 'utf8');
    console.log('Successfully updated logo (renamed variable) in App.tsx!');
  } else {
    // If not found, let's search for "LOGO_BASE64" to be sure
    const match = appContent.match(/const \w*LOGO_BASE64 = "[^"]+";/);
    if (match) {
      appContent = appContent.replace(match[0], `const RODOCHAGAS_LOGO_BASE64 = "${base64Logo}";`);
      fs.writeFileSync(appPath, appContent, 'utf8');
      console.log('Successfully updated logo (matched variable) in App.tsx!');
    } else {
      console.error('Could not find LOGO_BASE64 variable in App.tsx!');
    }
  }
}
