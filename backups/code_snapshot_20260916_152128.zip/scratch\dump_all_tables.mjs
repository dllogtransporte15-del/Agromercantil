import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  'https://gyvnhvnuidrfmqzielmv.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd5dm5odm51aWRyZm1xemllbG12Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQwMTY5ODksImV4cCI6MjA4OTU5Mjk4OX0.dK_l3INxOB9_HVYte43PCXFQLe8DnXgPitcxhNK4x30'
)

const tables = [
  'app_users', 'clients', 'owners', 'drivers', 'vehicles', 'products', 
  'cargos', 'shipments', 'branches', 'shipment_locks', 
  'profile_permissions', 'app_settings', 'tickets'
];

async function dumpStructures() {
  console.log('Querying one row from each table...');
  for (const table of tables) {
    const { data, error } = await supabase
      .from(table)
      .select('*')
      .limit(1);

    if (error) {
      console.log(`Table ${table} error:`, error.message);
    } else {
      console.log(`Table ${table} success! Row count: ${data.length}`);
      if (data.length > 0) {
        console.log(`Fields for ${table}:`, Object.keys(data[0]));
      } else {
        console.log(`Fields for ${table}: (empty)`);
      }
    }
  }
}

dumpStructures();
